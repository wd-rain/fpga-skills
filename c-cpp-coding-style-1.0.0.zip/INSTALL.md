# C/C++ 编码规范 Skill 安装包

包含 `c-cpp-coding-style/`（Skill、完整规范、clang-format 配置）和 Windows 安装脚本。所有文本为 UTF-8。

## Windows 安装

需要 PowerShell 7 或更新版本。把 ZIP 解压到临时目录，在该目录运行：

```powershell
pwsh -NoProfile -File ./install.ps1
```

默认安装到 `$CODEX_HOME/skills/c-cpp-coding-style`；未设置 `CODEX_HOME` 时使用用户目录下的 `.codex/skills/c-cpp-coding-style`。这是本机现有个人 Skill 使用的位置。也可以显式指定 Codex 数据目录：

```powershell
pwsh -NoProfile -File ./install.ps1 -CodexHome 'D:/CodexData'
```

可先加 `-WhatIf` 预览。脚本检查文件完整性，完整备份现有 `c-cpp-coding-style` 和旧 `embedded-c-coding`（目录可能叫 `ai-coding-skill` 或 `embedded-c-coding`），然后安装新版本。名称不符或遇到符号链接时停止，不覆盖其他 Skill。

备份位于所选 Codex 数据目录下的 `skill-backups/<时间戳>/`，不放在 `skills` 中，避免旧规则重复触发。脚本会打印安装路径和备份路径；重复安装会再次备份。失败时会尝试恢复已移动的版本，相关文件保留在备份目录中。

安装后在新的 Codex 任务中使用 `$c-cpp-coding-style`；如果列表尚未刷新，重启应用后再检查。当前对话已加载的旧 Skill 内容不会因磁盘替换而从历史中消失。

## 手动安装及恢复

也可以把 `c-cpp-coding-style` 文件夹复制到目标环境识别的个人 skills 目录。先把旧 `ai-coding-skill` / `embedded-c-coding` 文件夹移到扫描目录之外，避免两套规则同时加载。跨工具使用时，以该工具的 Skill 目录要求为准；ZIP 是文件分发包，不假定所有客户端支持直接导入 ZIP。

恢复旧版时，将新 Skill 文件夹移出 `skills`，把备份中的旧文件夹放回原来的位置，再刷新 Skill 列表。备份包含旧版全部参考资料及附带文件。

## 格式化配置

Skill 安装不自动改变工程。需要采用格式时，将 `c-cpp-coding-style/assets/linux-cpp.clang-format` 复制到目标工程，命名为 `.clang-format`。配套配置已在 clang-format 22.1.8 验证；其他版本先检查兼容性。命名规则由 Skill 指导和代码评审落实，clang-format 不会重命名变量。

该 Skill 以本次确认的规范替代旧版，涵盖变量作用域、常量按作用域命名、C 结构体 `_t`、函数指针 `_cb` / `_fn`、单行 `if` 和 C++ 资源管理。旧版额外的强制 OOP、固定十二阶段审查及署名要求没有带入。

Skill 文件结构参考 [OpenAI 官方 Skill 文档](https://learn.chatgpt.com/docs/build-skills)。
