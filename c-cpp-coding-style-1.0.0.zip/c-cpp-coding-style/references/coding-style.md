# 个人 C/C++ 编码规范

适用于自己的 C/C++ 应用与库。文件采用 UTF-8、LF 换行、末尾保留一个换行，不保留行尾空白。配套配置为 [linux-cpp.clang-format](../assets/linux-cpp.clang-format)，已使用本机 clang-format 22.1.8 验证。

## 1. 风格取舍

采用 Linux 风格的函数布局和简洁控制流，结合现代 C++ 的类型与资源管理习惯。C++ 并不存在唯一的排版标准；这里定义的是个人约定。C++ Core Guidelines 同样强调选择一致的风格，并保留外来库自身风格。[依据：C++ Core Guidelines，NL.8](https://isocpp.github.io/CppCoreGuidelines/CppCoreGuidelines.html#Rl-name)

| 项目 | 本规范 | 与参考风格的关系 |
| --- | --- | --- |
| 缩进 | 4 个空格，禁用 Tab | 个人选择；Linux 内核使用 8 列 Tab |
| 行宽 | 80 列目标 | 便于并排阅读；不可拆分的标识符、URL 和字符串可例外 |
| 函数定义 | 左大括号另起一行 | 沿用 Linux 风格；包括 C++ 成员函数 |
| 控制语句 | 左大括号同行，`else` 与前一个 `}` 同行 | 沿用 Linux 风格 |
| 单语句分支与循环 | 必须写大括号 | 个人选择；Linux 允许省略简单分支的大括号 |
| 指针与引用 | `const char *data`、`const Buffer &buffer` | 采用靠近变量名的统一写法 |
| C++ 类型 | `PascalCase` | 个人选择，用于区分类型和对象 |
| C++ 资源管理 | RAII、值语义、明确所有权 | 采用现代 C++ 习惯 |

向 Linux 内核提交代码时，以目标内核目录的实际规范和配置为准。[依据：Linux kernel coding style](https://cdn.kernel.org/doc/html/latest/process/coding-style.html)

## 2. 排版规则

1. 每行只写一条语句，每次声明只声明一个变量。
2. `if (`、`for (`、`while (`、`switch (` 留空格；函数调用写成 `read_data()`。
3. 二元运算符两侧留空格，逗号后留空格；不在括号内部增加空格。
4. 函数之间留一个空行，函数内部按逻辑阶段分段，不手动对齐连续赋值。
5. `switch` 与 `case` 同级，分支内容缩进一级。C++ 有意贯穿分支时写 `[[fallthrough]];`。
6. `class`、`struct`、`enum`、`namespace` 的左大括号同行；命名空间内部不增加缩进。
7. `public:`、`protected:`、`private:` 与类声明同级，成员缩进一级。
8. 多行参数采用续行缩进；一行放不下时，每个参数独占一行。由格式化器决定具体断行位置。
9. 允许不带 `else` 的简单 `if` 写成 `if (is_ready) { process_data(); }`，必须保留大括号，块内只有一条简单语句且整行不超过 80 列。带 `else`、包含多条语句或嵌套控制流时采用多行。循环仍使用多行布局；函数左大括号仍另起一行，但简短函数体可被格式化为单行块。

## 3. 命名规则

| 对象 | 规则 | 示例 |
| --- | --- | --- |
| 文件、目录 | `snake_case` | `packet_reader.cpp` |
| C 源码 / 头文件 | `.c` / `.h` | `packet_reader.h` |
| C++ 源码 / 头文件 | `.cpp` / `.hpp` | `packet_reader.hpp` |
| 函数、方法 | `snake_case`，动作明确 | `read_packet()`、`reset_count()` |
| 事件回调指针 | 名称主体加 `_cb` | `receive_cb` |
| 通用函数指针 | 名称主体加 `_fn` | `compare_fn` |
| 操作表中的函数指针成员 | 动作名称，不加 `_cb`、`_fn` | `ops->read` |
| 局部变量、参数、公开非静态数据成员 | `snake_case` | `retry_count`、`buffer_size` |
| 布尔值 | 使用表达判断的名称 | `is_ready`、`has_error`、`can_write` |
| C 的结构体标签 | `snake_case_t`，公共类型带模块前缀 | `struct packet_reader_t` |
| C 的枚举值 | 模块前缀加全大写 | `PACKET_STATUS_READY` |
| C++ 类、结构体、枚举类型、类型别名 | `PascalCase` | `PacketReader`、`ReadStatus` |
| C++ 私有非静态数据成员 | `snake_case_` | `retry_count_` |
| C++ 命名空间、枚举值 | `snake_case` | `io`、`ReadStatus::ready` |
| 宏、头文件保护宏 | `UPPER_SNAKE_CASE`，带项目或模块前缀 | `APP_ENABLE_LOG`、`APP_PACKET_READER_HPP` |

名称应说明用途和单位，如 `timeout_ms`、`size_bytes`。避免 `tmp1`、`data2` 等含糊名称；小范围循环可用 `i`。不使用双下划线或下划线开头的自定义名称。C 的结构体标签统一以 `_t` 结尾；C++ 类型仍使用 `PascalCase`。不为了满足本规范重命名第三方 API。

### 3.1 变量的作用域与生命周期

采用以下个人约定，通过名称区分跨模块状态、持久状态和临时数据。这些前后缀是本规范的选择，并非 Linux 内核或 C++ 标准的统一要求。

| 类别 | 命名规则 | 示例 | 使用范围 |
| --- | --- | --- | --- |
| 跨文件全局变量 | `g_<模块>_<名称>` | `g_app_is_running` | 具有外部链接，供其他源文件访问 |
| 文件内变量 | `s_snake_case` | `s_retry_count` | C 的文件级 `static`；C++ 的文件级 `static` 或匿名命名空间变量 |
| 普通局部变量 | `snake_case` | `retry_count` | 当前函数或语句块 |
| 函数参数 | `snake_case` | `timeout_ms` | 当前函数，不加 `p_` 或 `arg_` |
| 静态局部变量 | `s_snake_case` | `s_call_count` | 仅当前函数可见，值可跨调用保留 |
| 公开非静态成员 | `snake_case` | `packet.size_bytes` | 简单数据结构的字段 |
| 私有非静态成员 | `snake_case_` | `retry_count_` | 当前对象的内部状态 |
| 公开静态成员 | `s_snake_case` | `Reader::s_instance_count` | 同一类的所有对象共享 |
| 私有静态成员 | `s_snake_case_` | `s_instance_count_` | 类内部共享状态 |
| 线程局部变量 | 在对应作用域规则上加 `tl_` | `g_app_tl_error`、`s_tl_error` | 每个线程拥有独立实例 |

`g_` 按跨文件可访问性使用，不代表所有写在函数外的变量。可写全局变量应尽量少用，优先通过模块接口访问；确实需要时，在头文件中用 `extern` 声明，在一个源文件中定义。`s_` 不表示线程安全，静态局部变量也可能被并发访问。

布尔谓词和单位保留在名称主体中，例如 `g_app_is_running`、`s_is_ready`、`is_ready_`、`s_timeout_ms`。不额外编码基础类型，不使用 `i_count`、`u32_count` 或 `p_buffer`；名称应表达用途。

### 3.2 const 与 constexpr 对象

`const` 与 `constexpr` 对象按第 3.1 节的作用域和成员规则命名，不设置单独的常量前缀。例如局部对象写 `max_retries`，文件内对象写 `s_max_retries`，跨文件公开对象写 `g_app_max_retries`，私有非静态成员写 `limit_`，私有静态成员写 `s_max_retries_`。宏与枚举值继续遵守第 3 节的规则。

`const char *data` 表示通过该指针不能修改字符，指针本身仍可重新赋值，因此 `data` 按变量作用域命名。命名不能代替正确的 `const`、`constexpr`、链接属性和访问控制。

### 3.3 函数与函数指针

普通函数使用动词加对象，如 `read_packet()`；普通数据变量表达数据含义，如 `packet_count`。两者都使用 `snake_case`，通过语义区分。

事件通知、完成通知等回调指针使用 `_cb`，如 `receive_cb`、`complete_cb`；比较器、可替换算法等其他函数指针使用 `_fn`，如 `compare_fn`、`encode_fn`。事件回调优先使用 `_cb`，不叠加为 `_cb_fn`。这些是本规范的个人约定，不是 Linux 内核的统一要求。

函数指针仍属于变量，按“作用域前缀 + 名称主体 + 角色后缀 + 私有成员尾缀”组合：

| 类别 | 回调指针示例 | 通用函数指针示例 |
| --- | --- | --- |
| 局部变量、参数 | `receive_cb` | `compare_fn` |
| 跨文件全局变量 | `g_app_receive_cb` | `g_app_compare_fn` |
| 文件内变量、静态局部变量 | `s_receive_cb` | `s_compare_fn` |
| 私有非静态成员 | `receive_cb_` | `compare_fn_` |
| 公开静态成员 | `s_receive_cb` | `s_compare_fn` |
| 私有静态成员 | `s_receive_cb_` | `s_compare_fn_` |

操作表（如 `ops`）中的函数指针成员直接使用动作名称，如 `ops->read`、`ops->write`，因为操作表上下文已说明其角色。普通结构体中的回调字段仍使用 `_cb`。

`_cb`、`_fn` 标记存放或接收函数指针的变量及参数；被指向的实现函数仍按普通函数规则命名，例如 `handle_receive()`、`compare_packet()`。实际调用时，普通函数和函数指针都可以使用 `名称(...)`，因此不能仅凭调用括号区分。后缀也不代替接口对空指针、参数、返回值和有效期的约定。

### 3.4 命名示例

以下为 C++ 源文件中的声明片段；`extern` 声明对应的定义应只出现一次：

```cpp
extern bool g_app_is_running;
bool g_app_is_running = false;

namespace {
constexpr unsigned int s_max_retries = 3;
unsigned int s_retry_count = 0;
} // namespace
```

函数内普通变量写 `retry_count`，只读快照写 `const auto retry_count = reader.count();`；如果需要跨调用保留计数，则写 `static unsigned int s_call_count = 0;`。这三种含义不要混用。

## 4. 函数与控制流

- 一个函数完成一件事。以 80 行函数体、4 层控制流嵌套、5 个参数作为本规范的上限；接近上限时拆分职责，相关参数可组合成配置结构体。
- 优先使用参数校验和提前返回，减少嵌套；返回后不再包一层无意义的 `else`。
- 外部输入必须校验范围、长度及空值。断言表达内部契约，不能替代外部输入检查。
- 检查可能失败的操作，明确传播或处理错误，不静默吞掉失败。
- C 函数内部资源清理可使用含义明确的 `goto out_free_buffer`；C++ 使用 RAII 对象清理资源。
- 公共接口写明参数约束、所有权、失败行为；并发接口补充线程安全与回调执行上下文。

## 5. C 与 C++ 分别遵守的规则

### C

- 无参数函数写 `function(void)`。公共符号带模块前缀；文件内部函数和变量使用 `static`。
- 不修改指向内容时使用 `const T *`；注意这与限制指针本身赋值的 `T *const` 不同。
- 成对管理申请与释放，明确每个退出路径的资源状态。
- 常量按用途使用枚举、宏或 `static const`；需要 C 整数常量表达式的位置使用枚举或合适的宏。
- 优先使用函数替代函数式宏。必须使用多语句宏时采用 `do { ... } while (0)`，避免重复求值带副作用的参数。

### C++

- 无参数函数写 `function()`；使用 `nullptr`、`enum class`、`using` 类型别名。
- 优先值语义和标准容器；资源由 RAII 对象持有，动态独占所有权使用 `std::unique_ptr`，确有共享所有权才使用 `std::shared_ptr`。
- 原始指针、引用和视图默认不拥有资源，接口说明其有效期。不把裸 `new/delete` 散落在业务逻辑中。
- 只读参数、只读成员函数使用适当的 `const`；编译期常量优先 `constexpr`，避免用宏代替有类型常量。
- 成员在声明处或构造函数初始化列表中初始化；重写虚函数写 `override`，单参数转换构造函数通常写 `explicit`。
- `auto` 用于初始化式已经清楚表达类型的场景，避免隐藏关键的数值类型与单位；类型转换使用合适的 C++ 命名转换。
- 在项目层面统一异常或错误返回策略；必须处理或传播失败。`noexcept` 只用于确实保证不抛出的接口。
- 不在头文件中写 `using namespace`。文件内部辅助符号可放在 `.cpp` 的匿名命名空间中。

资源管理规则参考 [C++ Core Guidelines：R.1、R.3、R.20、R.21](https://isocpp.github.io/CppCoreGuidelines/CppCoreGuidelines.html#S-resource)。上面的命名、函数规模和扩展名选择是本规范的具体约定。

## 6. 头文件与注释

- 头文件必须自包含，使用含项目路径信息的保护宏；直接包含自己依赖的声明，不依赖偶然的间接包含。
- 源文件先包含自身头文件，再按项目既有依赖要求组织其他头文件，最后放标准库；组间空一行。不重排有顺序依赖的头文件。
- 注释说明意图、约束或选择原因，不复述语句。中文或英文都可以，同一模块保持一致；中文保持 UTF-8。
- 删除失效注释、注释掉的代码和死代码，历史交给版本管理。
- 第三方库和生成文件沿用原风格；格式检查只覆盖自己维护的源码。

## 7. 示例

以下展示 C++ 的命名、初始化、访问控制和大括号布局：

```cpp
class RetryCounter {
public:
    explicit RetryCounter(unsigned int limit) : limit_(limit)
    {
    }

    bool try_next()
    {
        if (retry_count_ >= limit_) { return false; }

        ++retry_count_;
        return true;
    }

    unsigned int count() const
    { return retry_count_; }

private:
    unsigned int limit_ = 0;
    unsigned int retry_count_ = 0;
};
```

## 8. 用工具落实

格式化工具叫 **clang-format**；**clangd** 为编辑器提供语言服务，并内置 clang-format 的格式化能力，两者读取 `.clang-format`。[依据：clangd Formatting](https://clangd.llvm.org/features#formatting)

将配套的 Skill 的 `assets/linux-cpp.clang-format` 复制到目标工程根目录，命名为 `.clang-format`。配置中的 `Language: Cpp` 用于这一套 C/C++ 排版规则；`Standard: Latest` 是格式化语法选项，不修改 CMake 的编译标准。

本配置关闭头文件自动排序和注释重排，保留人工组织；允许简单的单行 `if`，格式化时符合条件的多行 `if` 也可能被合并。自动插入大括号仍关闭，缺失大括号需手动修复或由 clang-tidy 辅助检查。clang-format 不执行命名检查，不保证函数长度、所有权、错误处理或文件编码。[依据：clang-format 配置项](https://clang.llvm.org/docs/ClangFormatStyleOptions.html)

允许带大括号的单行 `if` 需要启用 `AllowShortBlocksOnASingleLine: Always`。该选项也允许其他短语句块合并，包括示例中 `count()` 的函数体；`AllowShortFunctionsOnASingleLine: None` 保持函数签名与左大括号分行，但不能阻止这种函数体合并。

| 规则 | 执行方式 |
| --- | --- |
| 缩进、空格、大括号布局、断行 | clang-format / clangd 格式化 |
| 名称、缺失大括号、函数规模 | 人工检查，可加入 clang-tidy 检查 |
| UTF-8、文件末尾换行 | 编辑器设置 |
| 所有权、接口语义、错误处理 | 代码评审与测试 |

在采用配置的工程内使用实际可用的工具路径执行：

```sh
clang-format --version
clang-format --style=file -i src/app.cpp
clang-format --style=file --dry-run --Werror src/app.cpp
```

先确认最近一层 `.clang-format`，子目录配置优先。固定编辑器、命令行和 CI 使用的 clang-format/clangd 版本；旧版本可能不认识本配置的部分选项。只格式化本次需要处理的自有源码，保持第三方与生成文件原样。
