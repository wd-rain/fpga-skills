#Requires -Version 7.0
[CmdletBinding(SupportsShouldProcess)]
param([string]$CodexHome)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if ([string]::IsNullOrWhiteSpace($CodexHome)) {
    $CodexHome = if ($env:CODEX_HOME) { $env:CODEX_HOME } else {
        Join-Path ([Environment]::GetFolderPath('UserProfile')) '.codex'
    }
}
$installHome = [IO.Path]::GetFullPath($CodexHome)
$skillsRoot = Join-Path $installHome 'skills'
$backupRoot = Join-Path $installHome 'skill-backups'
$skillName = 'c-cpp-coding-style'
$source = Join-Path $PSScriptRoot $skillName
$target = Join-Path $skillsRoot $skillName

function Assert-ChildPath([string]$Path, [string]$Root) {
    $fullPath = [IO.Path]::GetFullPath($Path)
    $prefix = [IO.Path]::GetFullPath($Root).TrimEnd('\', '/') + [IO.Path]::DirectorySeparatorChar
    if (-not $fullPath.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Path escapes the intended directory: $fullPath"
    }
}

function Assert-NoLinks([string]$Path) {
    $cursor = [IO.Path]::GetFullPath($Path)
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            if ((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {
                throw "Refusing a symbolic link or junction: $cursor"
            }
        }
        $cursor = [IO.Path]::GetDirectoryName($cursor)
    }
    if (Test-Path -LiteralPath $Path -PathType Container) {
        foreach ($item in Get-ChildItem -LiteralPath $Path -Recurse -Force) {
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
                throw "Refusing a symbolic link or junction: $($item.FullName)"
            }
        }
    }
}

function Assert-SkillName([string]$Path, [string]$ExpectedName) {
    $entrypoint = Join-Path $Path 'SKILL.md'
    if (-not (Test-Path -LiteralPath $entrypoint -PathType Leaf)) {
        throw "SKILL.md is missing: $Path"
    }
    $content = Get-Content -LiteralPath $entrypoint -Raw -Encoding utf8
    $pattern = '(?ms)\A---\r?\n(?:(?!^---\r?$).)*?^name: *' + [regex]::Escape($ExpectedName) + ' *\r?$'
    if ($content -notmatch $pattern) { throw "Unexpected skill identity: $Path" }
}

function Get-Manifest([string]$Path) {
    @(Get-ChildItem -LiteralPath $Path -Recurse -File -Force | ForEach-Object {
        $relative = [IO.Path]::GetRelativePath($Path, $_.FullName)
        $hash = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
        "$relative $hash"
    } | Sort-Object)
}

Assert-NoLinks $source
Assert-SkillName $source $skillName
foreach ($required in @('references/coding-style.md', 'assets/linux-cpp.clang-format', 'agents/openai.yaml')) {
    if (-not (Test-Path -LiteralPath (Join-Path $source $required) -PathType Leaf)) {
        throw "Package is incomplete: $required"
    }
}
Assert-NoLinks $skillsRoot
Assert-NoLinks $backupRoot
Assert-ChildPath $target $skillsRoot
if ($source -eq $target -or $source.StartsWith($target + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Extract the installer outside the installed skill directory before running it.'
}

$replacements = @()
foreach ($candidate in @(
    @{ Folder = $skillName; Name = $skillName },
    @{ Folder = 'ai-coding-skill'; Name = 'embedded-c-coding' },
    @{ Folder = 'embedded-c-coding'; Name = 'embedded-c-coding' }
)) {
    $path = Join-Path $skillsRoot $candidate.Folder
    Assert-ChildPath $path $skillsRoot
    if (Test-Path -LiteralPath $path) {
        Assert-NoLinks $path
        Assert-SkillName $path $candidate.Name
        $replacements += $path
    }
}

if (-not $PSCmdlet.ShouldProcess($target, 'Install skill and move replaced versions to skill-backups')) { return }
$stamp = (Get-Date -Format 'yyyyMMdd-HHmmssfff') + '-' + [guid]::NewGuid().ToString('N').Substring(0, 8)
$backup = Join-Path $backupRoot $stamp
$staging = Join-Path $backup 'incoming'
Assert-ChildPath $backup $backupRoot
Assert-ChildPath $staging $backup
New-Item -ItemType Directory -Path $backup -Force | Out-Null
New-Item -ItemType Directory -Path $skillsRoot -Force | Out-Null
Copy-Item -LiteralPath $source -Destination $staging -Recurse
if (Compare-Object (Get-Manifest $source) (Get-Manifest $staging)) {
    throw "Staging verification failed. Existing skills are unchanged. Inspect: $staging"
}

$moved = [Collections.Generic.List[object]]::new()
$installed = $false
try {
    foreach ($path in $replacements) {
        $saved = Join-Path $backup (Split-Path -Leaf $path)
        Assert-ChildPath $path $skillsRoot
        Assert-ChildPath $saved $backup
        Move-Item -LiteralPath $path -Destination $saved
        $moved.Add(@{ Original = $path; Saved = $saved })
    }
    Assert-ChildPath $staging $backup
    Assert-ChildPath $target $skillsRoot
    Move-Item -LiteralPath $staging -Destination $target
    $installed = $true
    if (Compare-Object (Get-Manifest $source) (Get-Manifest $target)) {
        throw 'Installed file verification failed.'
    }
} catch {
    if ($installed) {
        $failed = Join-Path $backup 'failed-install'
        Assert-ChildPath $target $skillsRoot
        Assert-ChildPath $failed $backup
        Move-Item -LiteralPath $target -Destination $failed
    }
    for ($index = $moved.Count - 1; $index -ge 0; $index--) {
        Assert-ChildPath $moved[$index].Saved $backup
        Assert-ChildPath $moved[$index].Original $skillsRoot
        Move-Item -LiteralPath $moved[$index].Saved -Destination $moved[$index].Original
    }
    throw
}

[pscustomobject]@{
    InstalledPath = $target
    BackupPath = $backup
    ReplacedPaths = $replacements
}
